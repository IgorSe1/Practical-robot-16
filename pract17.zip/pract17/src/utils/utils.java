package utils;

import game.GameSettings;
import game.GameStats;

import java.io.*;

public class utils {
    static final String CONFIG_FILE = "config.txt";
    static final String STATS_FILE = "stats.txt";

    public static void saveConfig(GameSettings s) {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(CONFIG_FILE))) {
            w.write(s.gridSize + "\n" + s.playerX + "\n" + s.playerO + "\n");
        } catch (IOException e) {
            System.out.println("Помилка збереження конфігурації XoX");
        }
    }

    public static void loadConfig(GameSettings s) {
        try (BufferedReader r = new BufferedReader(new FileReader(CONFIG_FILE))) {
            s.gridSize = Integer.parseInt(r.readLine());
            s.playerX = r.readLine();
            s.playerO = r.readLine();
        } catch (IOException ignored) {}
    }

    public static void saveStats(GameStats stat) {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(STATS_FILE, true))) {
            w.write("Переможець: " + stat.winner + "\n");
            w.write("Символ гравця: " + stat.symbol + "\n");
            w.write("Розмір поля: " + stat.gridSize + "\n");
            w.write("Дата гри: " + stat.formattedDate + "\n\n");
        } catch (IOException e) {
            System.out.println("Помилка збереження статистики XoX");
        }
    }

    public static void loadStats() {
        try (BufferedReader r = new BufferedReader(new FileReader(STATS_FILE))) {
            String line;
            while ((line = r.readLine()) != null) System.out.println(line);
        } catch (IOException e) {
            System.out.println("Статистика відсутня або сталася помилка (X_X)");
        }
    }
}
