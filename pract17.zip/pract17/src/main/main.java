package main;

import game.game;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        game.run(scanner);
    }
}

