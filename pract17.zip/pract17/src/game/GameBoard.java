package game;

public class GameBoard {
    private final String[][] board;
    private final int gridSize;

    public GameBoard(int gridSize) {
        this.gridSize = gridSize;
        int rows = gridSize * 2 + 1;
        int cols = gridSize * 2 + 1;
        board = new String[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (i == 0 || i == rows - 1) board[i][j] = " ";
                else if (i % 2 == 0 && j % 2 == 0) board[i][j] = "+";
                else if (i % 2 == 0) board[i][j] = "-";
                else if (j % 2 == 0) board[i][j] = "|";
                else board[i][j] = " ";
            }
        }

        for (int i = 1; i < cols; i += 2) board[0][i] = Integer.toString(i / 2 + 1);
        for (int i = 1; i < rows; i += 2) board[i][0] = Integer.toString(i / 2 + 1);
    }

    public void print() {
        for (String[] row : board) {
            for (String cell : row) System.out.print(cell);
            System.out.println();
        }
    }

    public boolean placeSymbol(int row, int col, String symbol) {
        if (row < 0 || col < 0 || row >= gridSize || col >= gridSize) return false;
        int r = row * 2 + 1;
        int c = col * 2 + 1;
        if (board[r][c].equals(" ")) {
            board[r][c] = symbol;
            return true;
        }
        return false;
    }

    public boolean checkWin(String s) {
        for (int i = 1; i <= gridSize; i++) {
            if (getCell(i, 1).equals(s) && getCell(i, 2).equals(s) && getCell(i, 3).equals(s)) return true;
            if (getCell(1, i).equals(s) && getCell(2, i).equals(s) && getCell(3, i).equals(s)) return true;
        }
        return getCell(1, 1).equals(s) && getCell(2, 2).equals(s) && getCell(3, 3).equals(s)
                || getCell(1, 3).equals(s) && getCell(2, 2).equals(s) && getCell(3, 1).equals(s);
    }

    private String getCell(int row, int col) {
        return board[row * 2 - 1][col * 2 - 1];
    }

    public boolean isFull() {
        for (int r = 0; r < gridSize; r++)
            for (int c = 0; c < gridSize; c++)
                if (board[r * 2 + 1][c * 2 + 1].equals(" "))
                    return false;
        return true;
    }
}
