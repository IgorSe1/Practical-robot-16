package game;

import utils.utils;
import java.util.Scanner;

public class game {
    static GameSettings settings = new GameSettings();
    static GameStats[] stats = new GameStats[100];
    static int statsCount = 0;

    public static void run(Scanner scanner) {
        utils.loadConfig(settings);
        boolean exit = false;

        while (!exit) {
            System.out.println("\n__ Головне меню __");
            System.out.println("1) Грати (нова гра)");
            System.out.println("2) Налаштування");
            System.out.println("3) Переглянути статистику попередніх матчів");
            System.out.println("4) Вихід");
            System.out.print("Оберіть пункт меню: ");

            if (scanner.hasNextInt()) {
                int input = scanner.nextInt();
                scanner.nextLine();

                switch (input) {
                    case 1 -> playGame(scanner);
                    case 2 -> settingsMenu(scanner);
                    case 3 -> utils.loadStats();
                    case 4 -> {
                        utils.saveConfig(settings);
                        exit = true;
                    }
                    default -> System.out.println("Такого пункту немає :(");
                }
            } else {
                scanner.nextLine();
                System.out.println("Некоректний ввід x_x");
            }
        }
    }

    static void playGame(Scanner scanner) {
        GameStats stat = new GameStats(settings.gridSize);
        GameBoard board = new GameBoard(settings.gridSize);
        boolean isXTurn = true;

        while (true) {
            String currentPlayer = isXTurn ? "X" : "O";
            String playerName = isXTurn ? settings.playerX : settings.playerO;
            board.print();

            int row, col;
            while (true) {
                System.out.print("Гравець " + playerName + " введіть стовпець (1-" + settings.gridSize + "): ");
                if (scanner.hasNextInt()) col = scanner.nextInt() - 1;
                else {
                    System.out.println("Некоректний ввід #_#"); scanner.next(); continue;
                }

                System.out.print("Гравець " + playerName + " введіть рядок ---> (1-" + settings.gridSize + "): ");
                if (scanner.hasNextInt()) row = scanner.nextInt() - 1;
                else {
                    System.out.println("Некоректний ввід X_X"); scanner.next(); continue;
                }

                if (!board.placeSymbol(row, col, currentPlayer)) {
                    System.out.println("Клітинка зайнята або некоректний ввід >_<");
                    continue;
                }
                break;
            }

            if (board.checkWin(currentPlayer)) {
                board.print();
                System.out.println("Переміг :) " + playerName + " (" + currentPlayer + ")");
                stat.winner = playerName;
                stat.symbol = currentPlayer;
                utils.saveStats(stat);
                stats[statsCount++] = stat;
                break;
            }

            if (board.isFull()) {
                board.print();
                System.out.println("Нічия (0_0)");
                stat.winner = "Нічия";
                stat.symbol = "-";
                utils.saveStats(stat);
                stats[statsCount++] = stat;
                break;
            }

            isXTurn = !isXTurn;
        }
    }

    static void settingsMenu(Scanner scanner) {
        boolean settingsMenu = true;
        while (settingsMenu) {
            System.out.println("__ Налаштування __");
            System.out.println("1) Змінити розмір поля");
            System.out.println("2) Змінити ім'я гравця X");
            System.out.println("3) Змінити ім'я гравця O");
            System.out.println("4) Повернутись у головне меню");
            System.out.print("Виберіть пункт меню: ");

            if (scanner.hasNextInt()) {
                int input = scanner.nextInt();
                scanner.nextLine();
                switch (input) {
                    case 1 -> {
                        System.out.print("Введіть розмір поля (3, 5, 7, 9): ");
                        int size = scanner.nextInt();
                        scanner.nextLine();
                        if (size == 3 || size == 5 || size == 7 || size == 9) settings.gridSize = size;
                        else System.out.println("Некоректний розмір -(0_0)-");
                    }
                    case 2 -> {
                        System.out.print("Нове ім'я для гравця X: ");
                        settings.playerX = scanner.nextLine();
                    }
                    case 3 -> {
                        System.out.print("Нове ім'я для гравця O: ");
                        settings.playerO = scanner.nextLine();
                    }
                    case 4 -> settingsMenu = false;
                    default -> System.out.println("Некоректний вибір x_x");
                }
            } else {
                scanner.nextLine();
                System.out.println("Некоректний ввід #_#");
            }
        }
    }
}
