package game;

public class GameSettings {
    public int gridSize = 3;
    public String playerX = "X";
    public String playerO = "O";
}
