package game;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GameStats {
    public String winner;
    public String symbol;
    public int gridSize;
    public String formattedDate;

    public GameStats(int gridSize) {
        this.gridSize = gridSize;
        LocalDateTime now = LocalDateTime.now();
        this.formattedDate = now.format(DateTimeFormatter.ofPattern("HH:mm dd.MM.yyyy"));
    }
}
