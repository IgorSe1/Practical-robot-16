package utils;

import java.io.*;

public class utils {
    static final String CONFIG_FILE = "config.txt";
    static final String STATS_FILE = "stats.txt";

    public static void saveConfig(int gridSize, String playerX, String playerO) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CONFIG_FILE))) {
            writer.write(gridSize + "\n" + playerX + "\n" + playerO + "\n");
        } catch (IOException e) {
            System.out.println("Помилка збереження конфігурації XoX");
        }
    }

    public static void loadConfig() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CONFIG_FILE))) {
            reader.readLine();
            reader.readLine();
            reader.readLine();
        } catch (IOException ignored) {}
    }

    public static void saveStats(String winner, String symbol, int gridSize, String time, String day, String month, String year) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STATS_FILE, true))) {
            writer.write("Переможець: " + winner + "\n");
            writer.write("Символ гравця: " + symbol + "\n");
            writer.write("Розмір поля: " + gridSize + "\n");
            writer.write("Дата гри: " + time + "/" + day + "." + month + "." + year + "\n\n");
        } catch (IOException e) {
            System.out.println("Помилка збереження статистики XoX");
        }
    }

    public static void loadStats() {
        try (BufferedReader reader = new BufferedReader(new FileReader(STATS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) System.out.println(line);
        } catch (IOException e) {
            System.out.println("Статистика відсутня або сталася помилка (X_X)");
        }
    }
}
