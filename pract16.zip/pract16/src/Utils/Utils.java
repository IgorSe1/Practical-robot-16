import java.io.*;
import java.util.Scanner;

public class Utils {
    static int gridSize = 3;
    static String playerX = "X";
    static String playerO = "O";
    static final String CONFIG_FILE = "config.txt";
    static final String STATS_FILE = "stats.txt";

    static void saveConfig() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CONFIG_FILE))) {
            writer.write(String.valueOf(gridSize));
            writer.newLine();
            writer.write(playerX);
            writer.newLine();
            writer.write(playerO);
        } catch (IOException e) {
            System.out.println("Помилка збереження конфігурації XoX");
        }
    }

    static void loadConfig() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CONFIG_FILE))) {
            gridSize = Integer.parseInt(reader.readLine());
            playerX = reader.readLine();
            playerO = reader.readLine();
        } catch (IOException e) {
        }
    }

    static void loadStats() {
        try (BufferedReader reader = new BufferedReader(new FileReader(STATS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Статистика відсутня або сталася помилка (X_X)");
        }
    }

    static void settingsMenu(Scanner scanner) {
        boolean settings = true;
        while (settings) {
            System.out.println("__ Налаштування __");
            System.out.println("1) Змінити розмір поля");
            System.out.println("2) Змінити ім'я гравця X");
            System.out.println("3) Змінити ім'я гравця O");
            System.out.println("4) Повернутись у головне меню");
            System.out.print("Виберіть пункт меню: ");

            if (scanner.hasNextInt()) {
                int input = scanner.nextInt();
                scanner.nextLine();

                switch (input) {
                    case 1:
                        System.out.print("Введіть розмір поля (3, 5, 7, 9): ");
                        if (scanner.hasNextInt()) {
                            int size = scanner.nextInt();
                            scanner.nextLine();
                            if (size == 3 || size == 5 || size == 7 || size == 9) {
                                gridSize = size;
                            } else {
                                System.out.println("Некоректний розмір -(0_0)-");
                            }
                        }
                        break;
                    case 2:
                        System.out.print("Нове ім'я для гравця X: ");
                        playerX = scanner.nextLine();
                        break;
                    case 3:
                        System.out.print("Нове ім'я для гравця O: ");
                        playerO = scanner.nextLine();
                        break;
                    case 4:
                        settings = false;
                        break;
                    default:
                        System.out.println("Некоректний вибір x_x");
                }
            } else {
                scanner.nextLine();
                System.out.println("Некоректний ввід #_#");
            }
        }
    }
}
