package Main;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        utils.loadConfig();
        boolean exit = false;

        while (!exit) {
            System.out.println("\n__ Головне меню __");
            System.out.println("1) Грати (нова гра)");
            System.out.println("2) Налаштування");
            System.out.println("3) Переглянути статистику попередніх матчів");
            System.out.println("4) Вихід");
            System.out.print("Оберіть пункт меню: ");

            if (scanner.hasNextInt()) {
                int input = scanner.nextInt();
                scanner.nextLine();

                switch (input) {
                    case 1 -> game.playGame(scanner);
                    case 2 -> utils.settingsMenu(scanner);
                    case 3 -> utils.loadStats();
                    case 4 -> {
                        utils.saveConfig();
                        exit = true;
                    }
                    default -> System.out.println("Такого пункту немає :(");
                }
            } else {
                scanner.nextLine();
                System.out.println("Некоректний ввід x_x");
            }
        }

        scanner.close();
    }
}
